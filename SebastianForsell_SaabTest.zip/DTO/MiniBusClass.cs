﻿using RentingSystem.Interfaces;

namespace RentingSystem.Classes
{
    class MiniBusClass : Vehicle
    {
        public override string Type
        {
            get
            {
                return "Mini bus";
            }
        }
    }
}
